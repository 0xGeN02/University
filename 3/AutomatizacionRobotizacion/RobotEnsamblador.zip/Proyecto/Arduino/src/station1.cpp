#include <Arduino.h>
#include "station1.h"

void setup() {
    setupStation1();
}

void loop() {
    loopStation1();
}