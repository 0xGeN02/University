#include <Arduino.h>
#include "station2.h"

void setup() {
    setupStation2();
}

void loop() {
    loopStation2();
}