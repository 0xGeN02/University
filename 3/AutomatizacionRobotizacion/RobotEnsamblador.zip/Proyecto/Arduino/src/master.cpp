#include <Arduino.h>
#include "master.h"

void setup() {
    setupMaster();
}

void loop() {
    loopMaster();
}