#ifndef STATION2_H
#define STATION2_H

void setupStation2();
void loopStation2();

#endif // STATION2_H