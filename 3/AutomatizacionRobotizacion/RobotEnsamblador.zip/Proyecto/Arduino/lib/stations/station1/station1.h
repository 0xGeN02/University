#ifndef STATION1_H
#define STATION1_H

void setupStation1();
void loopStation1();

#endif // STATION1_H