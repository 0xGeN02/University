#ifndef MASTER_H
#define MASTER_H

void setupMaster();
void loopMaster();

#endif // MASTER_H