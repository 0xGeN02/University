# Proyecto Automatizacion

[Instalación Platformio]

```zsh
    pip install platformio
```

* Tras instalar, hay que comprobar el c_cpp_properties.json mediante un:

```zsh
    pio run -v
```

Si se compila, el setup esta correcto.
