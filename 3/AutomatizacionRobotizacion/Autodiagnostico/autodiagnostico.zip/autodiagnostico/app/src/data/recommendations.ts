export const getRecommendations = (category: string, percentage: number): string => {
    switch (category) {
      case 'General':
        return getGeneralRecommendations(percentage);
      case 'Sector':
        return getSectorRecommendations(percentage);
      case 'Mercado':
        return getMarketRecommendations(percentage);
      default:
        return '';
    }
  };
  
  const getGeneralRecommendations = (percentage: number): string => {
    if (percentage < 50) {
      return `En la categoría General, se recomienda mejorar significativamente los procesos de digitalización y robotización. Aquí hay algunas sugerencias:
      1. Evaluar las áreas clave donde la digitalización puede tener el mayor impacto.
      2. Implementar herramientas y tecnologías que puedan automatizar tareas repetitivas.
      3. Capacitar al personal en el uso de nuevas tecnologías.
      4. Establecer un plan de acción claro con objetivos y plazos específicos.
      5. Monitorear y evaluar continuamente el progreso y ajustar las estrategias según sea necesario.`;
    } else if (percentage < 75) {
      return `En la categoría General, se recomienda continuar mejorando los procesos de digitalización y robotización. Aquí hay algunas sugerencias:
      1. Optimizar las tecnologías y herramientas existentes para mejorar la eficiencia.
      2. Explorar nuevas tecnologías que puedan complementar las soluciones actuales.
      3. Fomentar una cultura de innovación y mejora continua entre el personal.
      4. Realizar auditorías periódicas para identificar áreas de mejora.
      5. Invertir en formación y desarrollo continuo del personal.`;
    } else {
      return `En la categoría General, se considera que los procesos de digitalización y robotización están bien implementados, pero siempre hay espacio para mejoras continuas. Aquí hay algunas sugerencias:
      1. Mantenerse actualizado con las últimas tendencias y tecnologías en digitalización y robotización.
      2. Realizar pruebas piloto de nuevas tecnologías antes de una implementación completa.
      3. Fomentar la colaboración y el intercambio de conocimientos entre departamentos.
      4. Establecer métricas claras para medir el éxito de las iniciativas de digitalización.
      5. Continuar invirtiendo en la formación y el desarrollo del personal para mantener un alto nivel de competencia.`;
    }
  };
  
  const getSectorRecommendations = (percentage: number): string => {
    if (percentage < 50) {
      return `En la categoría Sector, se recomienda mejorar significativamente los procesos de digitalización y robotización. Aquí hay algunas sugerencias:
      1. Evaluar las áreas clave donde la digitalización puede tener el mayor impacto.
      2. Implementar herramientas y tecnologías que puedan automatizar tareas repetitivas.
      3. Capacitar al personal en el uso de nuevas tecnologías.
      4. Establecer un plan de acción claro con objetivos y plazos específicos.
      5. Monitorear y evaluar continuamente el progreso y ajustar las estrategias según sea necesario.`;
    } else if (percentage < 75) {
      return `En la categoría Sector, se recomienda continuar mejorando los procesos de digitalización y robotización. Aquí hay algunas sugerencias:
      1. Optimizar las tecnologías y herramientas existentes para mejorar la eficiencia.
      2. Explorar nuevas tecnologías que puedan complementar las soluciones actuales.
      3. Fomentar una cultura de innovación y mejora continua entre el personal.
      4. Realizar auditorías periódicas para identificar áreas de mejora.
      5. Invertir en formación y desarrollo continuo del personal.`;
    } else {
      return `En la categoría Sector, se considera que los procesos de digitalización y robotización están bien implementados, pero siempre hay espacio para mejoras continuas. Aquí hay algunas sugerencias:
      1. Mantenerse actualizado con las últimas tendencias y tecnologías en digitalización y robotización.
      2. Realizar pruebas piloto de nuevas tecnologías antes de una implementación completa.
      3. Fomentar la colaboración y el intercambio de conocimientos entre departamentos.
      4. Establecer métricas claras para medir el éxito de las iniciativas de digitalización.
      5. Continuar invirtiendo en la formación y el desarrollo del personal para mantener un alto nivel de competencia.`;
    }
  };
  
  const getMarketRecommendations = (percentage: number): string => {
    if (percentage < 50) {
      return `En la categoría Mercado, se recomienda mejorar significativamente los procesos de digitalización y robotización. Aquí hay algunas sugerencias:
      1. Evaluar las áreas clave donde la digitalización puede tener el mayor impacto.
      2. Implementar herramientas y tecnologías que puedan automatizar tareas repetitivas.
      3. Capacitar al personal en el uso de nuevas tecnologías.
      4. Establecer un plan de acción claro con objetivos y plazos específicos.
      5. Monitorear y evaluar continuamente el progreso y ajustar las estrategias según sea necesario.`;
    } else if (percentage < 75) {
      return `En la categoría Mercado, se recomienda continuar mejorando los procesos de digitalización y robotización. Aquí hay algunas sugerencias:
      1. Optimizar las tecnologías y herramientas existentes para mejorar la eficiencia.
      2. Explorar nuevas tecnologías que puedan complementar las soluciones actuales.
      3. Fomentar una cultura de innovación y mejora continua entre el personal.
      4. Realizar auditorías periódicas para identificar áreas de mejora.
      5. Invertir en formación y desarrollo continuo del personal.`;
    } else {
      return `En la categoría Mercado, se considera que los procesos de digitalización y robotización están bien implementados, pero siempre hay espacio para mejoras continuas. Aquí hay algunas sugerencias:
      1. Mantenerse actualizado con las últimas tendencias y tecnologías en digitalización y robotización.
      2. Realizar pruebas piloto de nuevas tecnologías antes de una implementación completa.
      3. Fomentar la colaboración y el intercambio de conocimientos entre departamentos.
      4. Establecer métricas claras para medir el éxito de las iniciativas de digitalización.
      5. Continuar invirtiendo en la formación y el desarrollo del personal para mantener un alto nivel de competencia.`;
    }
  };