export const generalQuestions = [
    {
        id: 1,
        question: '¿Cuál es el principal objetivo de su empresa en el próximo año?',
        options: [
            { text: 'Aumentar ingresos', weight: 4 },
            { text: 'Expandir la clientela', weight: 3 },
            { text: 'Mejorar la eficiencia', weight: 2 },
            { text: 'Innovar en productos/servicios', weight: 1 }
        ]
    },
    {
        id: 2,
        question: '¿Qué tan importante es la sostenibilidad para su empresa?',
        options: [
            { text: 'Muy importante', weight: 4 },
            { text: 'Algo importante', weight: 3 },
            { text: 'Poco importante', weight: 2 },
            { text: 'No importante', weight: 1 }
        ]
    },
    {
        id: 3,
        question: '¿Cómo evalúan el desempeño de sus empleados?',
        options: [
            { text: 'Evaluaciones anuales', weight: 3 },
            { text: 'Revisión continua', weight: 4 },
            { text: 'Feedback informal', weight: 2 },
            { text: 'No se evalúa', weight: 1 }
        ]
    },
    {
        id: 4,
        question: '¿Qué herramientas digitales utilizan para la gestión de proyectos?',
        options: [
            { text: 'Ninguna', weight: 1 },
            { text: 'Hojas de cálculo', weight: 2 },
            { text: 'Software de gestión de proyectos', weight: 3 },
            { text: 'Herramientas especializadas', weight: 4 }
        ]
    },
    {
        id: 5,
        question: '¿Cuál es su principal canal de comunicación con los clientes?',
        options: [
            { text: 'Correo electrónico', weight: 3 },
            { text: 'Teléfono', weight: 2 },
            { text: 'Redes sociales', weight: 4 },
            { text: 'Encuentros cara a cara', weight: 1 }
        ]
    },
    {
        id: 6,
        question: '¿Cómo manejan la formación y desarrollo profesional de sus empleados?',
        options: [
            { text: 'No se proporciona formación', weight: 1 },
            { text: 'Formación ocasional', weight: 2 },
            { text: 'Programas de formación continua', weight: 3 },
            { text: 'Plan de desarrollo individual', weight: 4 }
        ]
    },
    {
        id: 7,
        question: '¿Qué tan satisfechos están sus empleados con su entorno laboral?',
        options: [
            { text: 'Muy satisfechos', weight: 4 },
            { text: 'Satisfechos', weight: 3 },
            { text: 'Insatisfechos', weight: 2 },
            { text: 'Muy insatisfechos', weight: 1 }
        ]
    },
    {
        id: 8,
        question: '¿Cuál es su enfoque hacia la gestión de riesgos?',
        options: [
            { text: 'No se gestionan', weight: 1 },
            { text: 'Evaluación periódica', weight: 2 },
            { text: 'Planificación de contingencias', weight: 3 },
            { text: 'Enfoque proactivo', weight: 4 }
        ]
    },
    {
        id: 9,
        question: '¿Cómo se mantiene informado sobre las tendencias del mercado?',
        options: [
            { text: 'Investigaciones internas', weight: 2 },
            { text: 'Fuentes externas', weight: 3 },
            { text: 'Redes profesionales', weight: 4 },
            { text: 'No se realiza seguimiento', weight: 1 }
        ]
    },
    {
        id: 10,
        question: '¿Cuál es su estrategia para la retención de clientes?',
        options: [
            { text: 'No hay estrategia', weight: 1 },
            { text: 'Ofertas y promociones', weight: 2 },
            { text: 'Programa de fidelización', weight: 3 },
            { text: 'Atención personalizada', weight: 4 }
        ]
    }
];

export const educationSectorQuestions = [
    {
        id: 11,
        question: '¿Qué tan integrados están los recursos tecnológicos en el aula?',
        options: [
            { text: 'Ninguna integración', weight: 1 },
            { text: 'Integración básica (por ejemplo, proyector)', weight: 2 },
            { text: 'Integración moderada (uso de computadoras)', weight: 3 },
            { text: 'Integración total (tecnología como parte del currículo)', weight: 4 }
        ]
    },
    {
        id: 12,
        question: '¿Cómo se gestionan las evaluaciones y el rendimiento académico?',
        options: [
            { text: 'Métodos tradicionales en papel', weight: 1 },
            { text: 'Evaluaciones digitales ocasionales', weight: 2 },
            { text: 'Sistema de gestión de aprendizaje', weight: 3 },
            { text: 'Análisis de datos de rendimiento en tiempo real', weight: 4 }
        ]
    },
    {
        id: 13,
        question: '¿Qué plataformas digitales utilizan para la enseñanza?',
        options: [
            { text: 'Ninguna', weight: 1 },
            { text: 'Plataformas de videoconferencia', weight: 2 },
            { text: 'Plataformas de gestión de aprendizaje (LMS)', weight: 3 },
            { text: 'Estrategia educativa digital completa', weight: 4 }
        ]
    },
    {
        id: 14,
        question: '¿Cómo se fomenta la participación de los estudiantes en línea?',
        options: [
            { text: 'No se fomenta', weight: 1 },
            { text: 'Participación ocasional', weight: 2 },
            { text: 'Iniciativas específicas para fomentar participación', weight: 3 },
            { text: 'Estrategias integrales para la participación activa', weight: 4 }
        ]
    },
    {
        id: 15,
        question: '¿Qué tan accesibles son los recursos educativos para todos los estudiantes?',
        options: [
            { text: 'Poco accesibles', weight: 1 },
            { text: 'Accesibles para algunos', weight: 2 },
            { text: 'Mayormente accesibles', weight: 3 },
            { text: 'Totalmente accesibles para todos', weight: 4 }
        ]
    },
    {
        id: 16,
        question: '¿Cómo se actualizan los contenidos educativos?',
        options: [
            { text: 'Sin actualizaciones', weight: 1 },
            { text: 'Actualizaciones ocasionales', weight: 2 },
            { text: 'Revisiones anuales', weight: 3 },
            { text: 'Actualización continua y relevante', weight: 4 }
        ]
    },
    {
        id: 17,
        question: '¿Qué tecnologías utilizan para apoyar a los estudiantes con necesidades especiales?',
        options: [
            { text: 'Ninguna', weight: 1 },
            { text: 'Herramientas básicas de asistencia', weight: 2 },
            { text: 'Recursos tecnológicos especializados', weight: 3 },
            { text: 'Estrategias inclusivas completas', weight: 4 }
        ]
    },
    {
        id: 18,
        question: '¿Qué tan bien capacitado está el personal en el uso de tecnología educativa?',
        options: [
            { text: 'Poco capacitado', weight: 1 },
            { text: 'Capacitación básica', weight: 2 },
            { text: 'Capacitación continua y especializada', weight: 3 },
            { text: 'Excelentemente capacitado en tecnología educativa', weight: 4 }
        ]
    },
    {
        id: 19,
        question: '¿Cómo se promueve el aprendizaje colaborativo en línea?',
        options: [
            { text: 'No se promueve', weight: 1 },
            { text: 'Promoción ocasional', weight: 2 },
            { text: 'Actividades colaborativas específicas', weight: 3 },
            { text: 'Estrategia integral de aprendizaje colaborativo', weight: 4 }
        ]
    },
    {
        id: 20,
        question: '¿Qué tan bien se gestionan los recursos educativos digitales?',
        options: [
            { text: 'Sin gestión', weight: 1 },
            { text: 'Gestión básica', weight: 2 },
            { text: 'Gestión organizada y planificada', weight: 3 },
            { text: 'Gestión óptima y en continua evolución', weight: 4 }
        ]
    }
];

export const healthSectorQuestions = [
    {
        id: 21,
        question: '¿Qué tan integrados están los sistemas de gestión de pacientes?',
        options: [
            { text: 'Sin integración', weight: 1 },
            { text: 'Integración básica (sistemas independientes)', weight: 2 },
            { text: 'Integración moderada (algunos sistemas conectados)', weight: 3 },
            { text: 'Integración total (todos los sistemas interconectados)', weight: 4 }
        ]
    },
    {
        id: 22,
        question: '¿Qué tecnologías utilizan para el diagnóstico y tratamiento?',
        options: [
            { text: 'Tecnologías tradicionales', weight: 1 },
            { text: 'Tecnologías digitales ocasionales', weight: 2 },
            { text: 'Sistemas avanzados de diagnóstico', weight: 3 },
            { text: 'Tecnología de vanguardia en tratamiento y diagnóstico', weight: 4 }
        ]
    },
    {
        id: 23,
        question: '¿Cómo gestionan la información de los pacientes?',
        options: [
            { text: 'Registro manual en papel', weight: 1 },
            { text: 'Base de datos digital básica', weight: 2 },
            { text: 'Sistema de gestión de información de pacientes', weight: 3 },
            { text: 'Análisis avanzado de datos de pacientes', weight: 4 }
        ]
    },
    {
        id: 24,
        question: '¿Qué tan accesibles son los servicios de salud para los pacientes?',
        options: [
            { text: 'Poco accesibles', weight: 1 },
            { text: 'Accesibles para algunos', weight: 2 },
            { text: 'Mayormente accesibles', weight: 3 },
            { text: 'Totalmente accesibles para todos', weight: 4 }
        ]
    },
    {
        id: 25,
        question: '¿Cómo se gestionan los procesos de atención al paciente?',
        options: [
            { text: 'Sin gestión', weight: 1 },
            { text: 'Gestión básica de procesos', weight: 2 },
            { text: 'Gestión organizada y planificada', weight: 3 },
            { text: 'Gestión óptima y continua', weight: 4 }
        ]
    },
    {
        id: 26,
        question: '¿Qué tan bien capacitado está el personal en el uso de tecnologías de salud?',
        options: [
            { text: 'Poco capacitado', weight: 1 },
            { text: 'Capacitación básica', weight: 2 },
            { text: 'Capacitación continua y especializada', weight: 3 },
            { text: 'Excelentemente capacitado en tecnología de salud', weight: 4 }
        ]
    },
    {
        id: 27,
        question: '¿Cómo se gestionan las citas y la programación de pacientes?',
        options: [
            { text: 'Sin sistema', weight: 1 },
            { text: 'Gestión manual de citas', weight: 2 },
            { text: 'Sistema digital básico de programación', weight: 3 },
            { text: 'Sistema avanzado de gestión de citas', weight: 4 }
        ]
    },
    {
        id: 28,
        question: '¿Qué tan efectivos son los canales de comunicación con los pacientes?',
        options: [
            { text: 'Poco efectivos', weight: 1 },
            { text: 'Efectivos ocasionales', weight: 2 },
            { text: 'Canales de comunicación activos', weight: 3 },
            { text: 'Comunicación integral y efectiva', weight: 4 }
        ]
    },
    {
        id: 29,
        question: '¿Qué tecnologías utilizan para la telemedicina?',
        options: [
            { text: 'Ninguna', weight: 1 },
            { text: 'Videoconferencia básica', weight: 2 },
            { text: 'Plataformas de telemedicina', weight: 3 },
            { text: 'Telemedicina integral y avanzada', weight: 4 }
        ]
    },
    {
        id: 30,
        question: '¿Cómo se realiza la gestión de la salud preventiva?',
        options: [
            { text: 'Sin gestión', weight: 1 },
            { text: 'Gestión básica de salud preventiva', weight: 2 },
            { text: 'Programas de salud preventiva', weight: 3 },
            { text: 'Estrategia integral de salud preventiva', weight: 4 }
        ]
    }
];

export const manufacturingSectorQuestions = [
    {
        id: 31,
        question: '¿Qué tan automatizados están los procesos de producción?',
        options: [
            { text: 'Sin automatización', weight: 1 },
            { text: 'Automatización básica', weight: 2 },
            { text: 'Automatización parcial', weight: 3 },
            { text: 'Automatización total', weight: 4 }
        ]
    },
    {
        id: 32,
        question: '¿Cómo se gestiona la cadena de suministro?',
        options: [
            { text: 'Sin gestión', weight: 1 },
            { text: 'Gestión manual', weight: 2 },
            { text: 'Sistema de gestión de la cadena de suministro', weight: 3 },
            { text: 'Gestión optimizada y digitalizada', weight: 4 }
        ]
    },
    {
        id: 33,
        question: '¿Qué tecnologías utilizan para la monitorización de procesos?',
        options: [
            { text: 'Tecnología tradicional', weight: 1 },
            { text: 'Sistemas de monitoreo básicos', weight: 2 },
            { text: 'Sistemas avanzados de monitoreo', weight: 3 },
            { text: 'Monitoreo en tiempo real y automatizado', weight: 4 }
        ]
    },
    {
        id: 34,
        question: '¿Cómo se gestionan los datos de producción?',
        options: [
            { text: 'Sin gestión', weight: 1 },
            { text: 'Gestión manual', weight: 2 },
            { text: 'Sistema de gestión de datos de producción', weight: 3 },
            { text: 'Análisis avanzado de datos de producción', weight: 4 }
        ]
    },
    {
        id: 35,
        question: '¿Qué tan flexible es su proceso de producción para adaptarse a cambios?',
        options: [
            { text: 'Poca flexibilidad', weight: 1 },
            { text: 'Flexibilidad moderada', weight: 2 },
            { text: 'Flexibilidad considerable', weight: 3 },
            { text: 'Alta flexibilidad y adaptación continua', weight: 4 }
        ]
    },
    {
        id: 36,
        question: '¿Cómo se gestionan los residuos generados en la producción?',
        options: [
            { text: 'Sin gestión', weight: 1 },
            { text: 'Gestión básica de residuos', weight: 2 },
            { text: 'Programa de gestión de residuos', weight: 3 },
            { text: 'Gestión integral y sostenible de residuos', weight: 4 }
        ]
    },
    {
        id: 37,
        question: '¿Qué tecnologías utilizan para mejorar la calidad del producto?',
        options: [
            { text: 'Sin tecnología', weight: 1 },
            { text: 'Tecnologías básicas', weight: 2 },
            { text: 'Sistemas de control de calidad', weight: 3 },
            { text: 'Análisis de calidad basado en datos', weight: 4 }
        ]
    },
    {
        id: 38,
        question: '¿Qué tan capacitado está el personal en el uso de tecnologías de producción?',
        options: [
            { text: 'Poco capacitado', weight: 1 },
            { text: 'Capacitación básica', weight: 2 },
            { text: 'Capacitación continua y especializada', weight: 3 },
            { text: 'Excelentemente capacitado en tecnología de producción', weight: 4 }
        ]
    },
    {
        id: 39,
        question: '¿Cómo se gestionan los costos de producción?',
        options: [
            { text: 'Sin gestión', weight: 1 },
            { text: 'Gestión básica de costos', weight: 2 },
            { text: 'Sistema de gestión de costos', weight: 3 },
            { text: 'Análisis exhaustivo de costos', weight: 4 }
        ]
    }
];

export const commerceSectorQuestions = [
    {
        id: 41,
        question: '¿Qué tan integradas están las plataformas de venta online y física?',
        options: [
            { text: 'Sin integración', weight: 1 },
            { text: 'Integración básica', weight: 2 },
            { text: 'Integración moderada', weight: 3 },
            { text: 'Integración total', weight: 4 }
        ]
    },
    {
        id: 42,
        question: '¿Qué tecnologías utilizan para la gestión de inventarios?',
        options: [
            { text: 'Gestión manual', weight: 1 },
            { text: 'Sistema de gestión de inventarios básico', weight: 2 },
            { text: 'Sistema avanzado de gestión de inventarios', weight: 3 },
            { text: 'Inventario en tiempo real y automatizado', weight: 4 }
        ]
    },
    {
        id: 43,
        question: '¿Qué tan efectivos son sus canales de atención al cliente?',
        options: [
            { text: 'Poco efectivos', weight: 1 },
            { text: 'Efectivos ocasionales', weight: 2 },
            { text: 'Canales de atención activa', weight: 3 },
            { text: 'Comunicación integral y efectiva', weight: 4 }
        ]
    },
    {
        id: 44,
        question: '¿Cómo gestionan las promociones y descuentos?',
        options: [
            { text: 'Sin gestión', weight: 1 },
            { text: 'Gestión manual', weight: 2 },
            { text: 'Sistema de gestión de promociones', weight: 3 },
            { text: 'Estrategias automatizadas de promoción', weight: 4 }
        ]
    },
    {
        id: 45,
        question: '¿Qué tan rápido responden a las tendencias del mercado?',
        options: [
            { text: 'Poca rapidez', weight: 1 },
            { text: 'Rapidez moderada', weight: 2 },
            { text: 'Adaptación rápida', weight: 3 },
            { text: 'Adaptación constante y proactiva', weight: 4 }
        ]
    },
    {
        id: 46,
        question: '¿Qué tecnologías utilizan para el análisis de datos de ventas?',
        options: [
            { text: 'Sin análisis', weight: 1 },
            { text: 'Análisis básico', weight: 2 },
            { text: 'Análisis de datos de ventas regular', weight: 3 },
            { text: 'Análisis avanzado y en tiempo real', weight: 4 }
        ]
    },
    {
        id: 47,
        question: '¿Cómo gestionan la lealtad de los clientes?',
        options: [
            { text: 'Sin programa de lealtad', weight: 1 },
            { text: 'Programa básico de lealtad', weight: 2 },
            { text: 'Sistema de gestión de lealtad', weight: 3 },
            { text: 'Programa de lealtad personalizado y automatizado', weight: 4 }
        ]
    },
    {
        id: 48,
        question: '¿Qué tan accesibles son los métodos de pago para los clientes?',
        options: [
            { text: 'Poco accesibles', weight: 1 },
            { text: 'Accesibles para algunos métodos', weight: 2 },
            { text: 'Mayormente accesibles', weight: 3 },
            { text: 'Totalmente accesibles para todos los métodos', weight: 4 }
        ]
    },
    {
        id: 49,
        question: '¿Qué tecnologías utilizan para la gestión de envíos y logística?',
        options: [
            { text: 'Gestión manual', weight: 1 },
            { text: 'Sistema de gestión básico', weight: 2 },
            { text: 'Sistema avanzado de gestión de logística', weight: 3 },
            { text: 'Logística en tiempo real y automatizada', weight: 4 }
        ]
    }
];

export const servicesSectorQuestions = [
    {
        id: 51,
        question: '¿Qué tan digitalizados están los servicios que ofrecen?',
        options: [
            { text: 'Sin digitalización', weight: 1 },
            { text: 'Digitalización básica', weight: 2 },
            { text: 'Digitalización moderada', weight: 3 },
            { text: 'Totalmente digitalizados', weight: 4 }
        ]
    },
    {
        id: 52,
        question: '¿Cómo gestionan la atención al cliente?',
        options: [
            { text: 'Sin gestión', weight: 1 },
            { text: 'Gestión manual', weight: 2 },
            { text: 'Sistema de gestión de atención al cliente', weight: 3 },
            { text: 'Gestión avanzada y automatizada de atención', weight: 4 }
        ]
    },
    {
        id: 53,
        question: '¿Qué tan eficientes son sus procesos internos?',
        options: [
            { text: 'Poca eficiencia', weight: 1 },
            { text: 'Eficiencia moderada', weight: 2 },
            { text: 'Eficiencia considerable', weight: 3 },
            { text: 'Alta eficiencia y optimización continua', weight: 4 }
        ]
    },
    {
        id: 54,
        question: '¿Cómo se gestionan los datos de los clientes?',
        options: [
            { text: 'Sin gestión', weight: 1 },
            { text: 'Gestión manual de datos', weight: 2 },
            { text: 'Sistema de gestión de datos de clientes', weight: 3 },
            { text: 'Análisis avanzado de datos de clientes', weight: 4 }
        ]
    },
    {
        id: 55,
        question: '¿Qué tan accesibles son sus servicios para los clientes?',
        options: [
            { text: 'Poco accesibles', weight: 1 },
            { text: 'Accesibles para algunos', weight: 2 },
            { text: 'Mayormente accesibles', weight: 3 },
            { text: 'Totalmente accesibles para todos', weight: 4 }
        ]
    },
    {
        id: 56,
        question: '¿Qué tecnologías utilizan para la gestión de citas y reservas?',
        options: [
            { text: 'Sin gestión', weight: 1 },
            { text: 'Gestión manual de citas', weight: 2 },
            { text: 'Sistema de gestión de citas', weight: 3 },
            { text: 'Sistema avanzado de gestión de reservas', weight: 4 }
        ]
    },
    {
        id: 57,
        question: '¿Cómo se gestionan las quejas y reclamos de los clientes?',
        options: [
            { text: 'Sin gestión', weight: 1 },
            { text: 'Gestión básica de quejas', weight: 2 },
            { text: 'Sistema de gestión de reclamos', weight: 3 },
            { text: 'Gestión proactiva de quejas y mejoras', weight: 4 }
        ]
    },
    {
        id: 58,
        question: '¿Qué tan capacitado está el personal en el uso de tecnologías?',
        options: [
            { text: 'Poco capacitado', weight: 1 },
            { text: 'Capacitación básica', weight: 2 },
            { text: 'Capacitación continua y especializada', weight: 3 },
            { text: 'Excelentemente capacitado en tecnología de servicios', weight: 4 }
        ]
    },
    {
        id: 59,
        question: '¿Cómo gestionan la calidad del servicio ofrecido?',
        options: [
            { text: 'Sin gestión', weight: 1 },
            { text: 'Gestión básica de calidad', weight: 2 },
            { text: 'Sistema de gestión de calidad', weight: 3 },
            { text: 'Análisis exhaustivo y mejora continua', weight: 4 }
        ]
    }
];

export const tourismSectorQuestions = [
    {
        id: 61,
        question: '¿Qué tan digitalizados están los procesos de reserva de sus servicios turísticos?',
        options: [
            { text: 'Sin digitalización', weight: 1 },
            { text: 'Digitalización básica', weight: 2 },
            { text: 'Digitalización moderada', weight: 3 },
            { text: 'Totalmente digitalizados', weight: 4 }
        ]
    },
    {
        id: 62,
        question: '¿Qué tecnologías utilizan para la atención a clientes extranjeros?',
        options: [
            { text: 'Sin tecnología específica', weight: 1 },
            { text: 'Traductores básicos o manuales', weight: 2 },
            { text: 'Aplicaciones con soporte multilingüe', weight: 3 },
            { text: 'Sistemas avanzados de atención global', weight: 4 }
        ]
    },
    {
        id: 63,
        question: '¿Qué tan efectivas son sus estrategias de marketing digital para atraer turistas?',
        options: [
            { text: 'Poco efectivas', weight: 1 },
            { text: 'Efectividad moderada', weight: 2 },
            { text: 'Efectivas', weight: 3 },
            { text: 'Muy efectivas con campañas optimizadas', weight: 4 }
        ]
    },
    {
        id: 64,
        question: '¿Cómo gestionan los datos de los huéspedes o turistas?',
        options: [
            { text: 'Sin gestión de datos', weight: 1 },
            { text: 'Gestión básica', weight: 2 },
            { text: 'Sistema avanzado de gestión de clientes', weight: 3 },
            { text: 'Análisis avanzado para personalización', weight: 4 }
        ]
    },
    {
        id: 65,
        question: '¿Qué tan automatizados están los procesos internos de su negocio turístico?',
        options: [
            { text: 'Sin automatización', weight: 1 },
            { text: 'Automatización básica', weight: 2 },
            { text: 'Automatización parcial', weight: 3 },
            { text: 'Automatización completa', weight: 4 }
        ]
    },
    {
        id: 66,
        question: '¿Ofrecen experiencias personalizadas a través de tecnología?',
        options: [
            { text: 'No ofrecen personalización', weight: 1 },
            { text: 'Personalización básica', weight: 2 },
            { text: 'Personalización moderada', weight: 3 },
            { text: 'Experiencias personalizadas basadas en datos y tecnología', weight: 4 }
        ]
    },
    {
        id: 67,
        question: '¿Qué métodos digitales utilizan para la promoción de destinos?',
        options: [
            { text: 'Ninguno', weight: 1 },
            { text: 'Publicidad básica en redes sociales', weight: 2 },
            { text: 'Campañas publicitarias avanzadas', weight: 3 },
            { text: 'Estrategias integrales de marketing digital', weight: 4 }
        ]
    },
    {
        id: 68,
        question: '¿Cómo gestionan los comentarios y calificaciones de los turistas?',
        options: [
            { text: 'Sin gestión', weight: 1 },
            { text: 'Gestión manual', weight: 2 },
            { text: 'Sistema básico de gestión', weight: 3 },
            { text: 'Gestión avanzada para mejorar el servicio', weight: 4 }
        ]
    },
    {
        id: 69,
        question: '¿Qué tan eficiente es su sistema de gestión de itinerarios?',
        options: [
            { text: 'Poco eficiente', weight: 1 },
            { text: 'Eficiencia básica', weight: 2 },
            { text: 'Eficiencia moderada', weight: 3 },
            { text: 'Alta eficiencia con optimización tecnológica', weight: 4 }
        ]
    },
    {
        id: 70,
        question: '¿Cómo manejan la sostenibilidad en sus operaciones turísticas?',
        options: [
            { text: 'Sin estrategias sostenibles', weight: 1 },
            { text: 'Estrategias limitadas', weight: 2 },
            { text: 'Estrategias moderadas', weight: 3 },
            { text: 'Estrategias avanzadas y alineadas con sostenibilidad', weight: 4 }
        ]
    }
];

export const technologySectorQuestions = [
    {
        id: 71,
        question: '¿Cómo gestionan los procesos de innovación tecnológica?',
        options: [
            { text: 'Sin gestión', weight: 1 },
            { text: 'Gestión básica de innovación', weight: 2 },
            { text: 'Procesos moderados de innovación', weight: 3 },
            { text: 'Gestión avanzada y continua', weight: 4 }
        ]
    },
    {
        id: 72,
        question: '¿Qué tan automatizados están sus procesos de desarrollo de productos?',
        options: [
            { text: 'Sin automatización', weight: 1 },
            { text: 'Automatización básica', weight: 2 },
            { text: 'Automatización parcial', weight: 3 },
            { text: 'Automatización total', weight: 4 }
        ]
    },
    {
        id: 73,
        question: '¿Qué tan efectivos son sus sistemas de soporte técnico?',
        options: [
            { text: 'Poco efectivos', weight: 1 },
            { text: 'Efectividad moderada', weight: 2 },
            { text: 'Efectivos', weight: 3 },
            { text: 'Muy efectivos y optimizados', weight: 4 }
        ]
    },
    {
        id: 74,
        question: '¿Cómo manejan la ciberseguridad en su organización?',
        options: [
            { text: 'Sin estrategias', weight: 1 },
            { text: 'Estrategias básicas', weight: 2 },
            { text: 'Estrategias moderadas', weight: 3 },
            { text: 'Estrategias avanzadas', weight: 4 }
        ]
    },
    {
        id: 75,
        question: '¿Qué herramientas utilizan para la gestión de proyectos tecnológicos?',
        options: [
            { text: 'Herramientas básicas', weight: 1 },
            { text: 'Software de gestión básica', weight: 2 },
            { text: 'Herramientas avanzadas de gestión', weight: 3 },
            { text: 'Estrategias integrales de gestión de proyectos', weight: 4 }
        ]
    },
    {
        id: 76,
        question: '¿Qué porcentaje de su presupuesto invierten en investigación y desarrollo (I+D)?',
        options: [
            { text: 'Menos del 5%', weight: 1 },
            { text: 'Entre 5% y 10%', weight: 2 },
            { text: 'Entre 10% y 20%', weight: 3 },
            { text: 'Más del 20%', weight: 4 }
        ]
    },
    {
        id: 77,
        question: '¿Cómo gestionan la formación tecnológica de su personal?',
        options: [
            { text: 'Sin formación', weight: 1 },
            { text: 'Formación básica ocasional', weight: 2 },
            { text: 'Formación continua', weight: 3 },
            { text: 'Formación especializada avanzada', weight: 4 }
        ]
    },
    {
        id: 78,
        question: '¿Qué tan integrados están los sistemas tecnológicos dentro de la empresa?',
        options: [
            { text: 'Sin integración', weight: 1 },
            { text: 'Integración básica', weight: 2 },
            { text: 'Integración moderada', weight: 3 },
            { text: 'Totalmente integrados', weight: 4 }
        ]
    },
    {
        id: 79,
        question: '¿Cómo gestionan la relación con sus clientes en el ámbito tecnológico?',
        options: [
            { text: 'Sin gestión', weight: 1 },
            { text: 'Gestión básica', weight: 2 },
            { text: 'Gestión eficiente', weight: 3 },
            { text: 'Gestión avanzada y personalizada', weight: 4 }
        ]
    },
    {
        id: 80,
        question: '¿Qué tan efectivas son sus herramientas de análisis de datos tecnológicos?',
        options: [
            { text: 'Sin análisis', weight: 1 },
            { text: 'Análisis básico', weight: 2 },
            { text: 'Análisis moderado', weight: 3 },
            { text: 'Análisis avanzado y automatizado', weight: 4 }
        ]
    }
];
