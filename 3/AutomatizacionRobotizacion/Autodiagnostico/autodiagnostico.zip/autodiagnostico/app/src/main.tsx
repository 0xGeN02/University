// src/main.tsx
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/global.css';
import React from 'react';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const rootElement = document.getElementById('root');
if (rootElement) {
  const root = ReactDOM.createRoot(rootElement);
  root.render(
    <React.StrictMode>
      <App />
      <ToastContainer />
    </React.StrictMode>
  );
}