import React, { useState } from 'react';
import { Container, Paper, Typography, Box, Button } from '@mui/material';
import { questions } from '../data/questions';
import { SelectChangeEvent } from '@mui/material';
import Question from './Question';
import SectorSelector from './SectorSelector';
import ProgressBar from './ProgressBar';
import { toast } from 'react-toastify';
import '../styles/SurveyForm.css';

type Answer = {
  questionId: number;
  answer: string;
  weight: number;
  category?: string;
};

const SurveyForm: React.FC = () => {
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [selectedSector, setSelectedSector] = useState<string>('');

  const handleChange = (questionId: number, answer: string, weight: number, category?: string) => {
    setAnswers((prevAnswers) => {
      const existingAnswer = prevAnswers.find((ans) => ans.questionId === questionId);
      if (existingAnswer) {
        return prevAnswers.map((ans) =>
          ans.questionId === questionId ? { ...ans, answer, weight, category } : ans
        );
      } else {
        return [...prevAnswers, { questionId, answer, weight, category }];
      }
    });
  };

  const handleSectorChange = (event: SelectChangeEvent<string>) => {
    const sector = event.target.value as string;
    setSelectedSector(sector);
    console.log('Selected sector:', sector);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('General Answers:', answers);
    if (answers.length !== questions.length) {
      toast.warning('Por favor responde todas las preguntas generales', { autoClose: 3000 });
      return;
    }

    localStorage.setItem('generalAnswers', JSON.stringify(answers));

    switch (selectedSector) {
      case 'primario':
        window.location.href = '/survey/primario';
        break;
      case 'secundario':
        window.location.href = '/survey/secundario';
        break;
      case 'terciario':
        window.location.href = '/survey/terciario';
        break;
      default:
        toast.warning('Por favor selecciona un sector', { autoClose: 3000 });
    }
  };

  const completionPercentage = (answers.length / questions.length) * 100;

  const areGeneralQuestionsAnswered = questions.every(q => 
    answers.some(answer => answer.questionId === q.id)
  );

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <div className="progress-bar-container">
        <ProgressBar completionPercentage={completionPercentage} />
      </div>
      <Paper elevation={3} className="survey-form-container">
        <Typography variant="h4" gutterBottom className="survey-form-title">
          Encuesta de Madurez Digital
        </Typography>
        <form onSubmit={handleSubmit} className="survey-form">
          {questions.map((q) => (
            <Question
              key={q.id}
              id={q.id}
              question={q.question}
              options={q.options}
              handleChange={(answer, weight) => handleChange(q.id, answer, weight, q.category)}
            />
          ))}
          <SectorSelector 
            selectedSector={selectedSector} 
            handleSectorChange={handleSectorChange} 
            disabled={!areGeneralQuestionsAnswered}
          />
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
            <Button
              variant="contained"
              color="primary"
              type="submit"
              sx={{ px: 4, py: 1.5, fontSize: '1rem' }}
              disabled={!selectedSector}
            >
              Encuesta de Sector
            </Button>
          </Box>
        </form>
      </Paper>
    </Container>
  );
};

export default SurveyForm;