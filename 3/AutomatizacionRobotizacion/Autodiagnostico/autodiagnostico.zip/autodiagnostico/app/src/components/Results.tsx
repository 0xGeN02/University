import React, { useEffect, useState } from 'react';
import { Container, Paper, Typography, Box, Grid } from '@mui/material';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from 'recharts';
import { getRecommendations } from '../data/recommendations';
import '../styles/Results.css';

type Answer = {
  questionId: number;
  answer: string;
  weight: number;
  category?: string;
};

type ScoreData = {
  category: string;
  percentage: number;
  average: number;
};

const Results: React.FC = () => {
  const [data, setData] = useState<ScoreData[]>([]);
  const [recommendations, setRecommendations] = useState<string[]>([]);

  useEffect(() => {
    const generalAnswers: Answer[] = JSON.parse(localStorage.getItem('generalAnswers') || '[]');
    const sectorAnswers: Answer[] = JSON.parse(localStorage.getItem('sectorAnswers') || '[]');
    const marketAnswers: Answer[] = JSON.parse(localStorage.getItem('marketAnswers') || '[]');

    const calculateScores = (answers: Answer[]) => {
      const scores = { obtained: 0, max: 0 };
      answers.forEach((answer) => {
        scores.obtained += answer.weight;
        scores.max += 4; // Assuming the max weight for each question is 4
      });
      return scores;
    };

    const generalScores = calculateScores(generalAnswers);
    const sectorScores = calculateScores(sectorAnswers);
    const marketScores = calculateScores(marketAnswers);

    const combinedData: ScoreData[] = [
      { category: 'General', percentage: (generalScores.obtained / generalScores.max) * 100, average: 34 },
      { category: 'Sector', percentage: (sectorScores.obtained / sectorScores.max) * 100, average: 55 },
      { category: 'Mercado', percentage: (marketScores.obtained / marketScores.max) * 100, average: 29 },
    ];

    setData(combinedData);

    const recommendations = combinedData.map((score) => getRecommendations(score.category, score.percentage));
    setRecommendations(recommendations);
  }, []);

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Paper elevation={3} className="results-container">
        <Typography variant="h4" gutterBottom className="results-title">
          Resultados de la Encuesta
        </Typography>
        <Grid container spacing={4}>
          <Grid item xs={12} md={6}>
            <Typography variant="h6" gutterBottom className="chart-title">
              Gráfico de Barras
            </Typography>
            <Box className="chart-container">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="category" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip formatter={(value: number) => `${value.toFixed(2)}%`} />
                  <Legend />
                  <Bar dataKey="percentage" fill="#8884d8" name="Tu Empresa" />
                </BarChart>
              </ResponsiveContainer>
            </Box>
          </Grid>
          <Grid item xs={12}>
            <Typography variant="h6" gutterBottom className="chart-title">
              Gráfico de Radar
            </Typography>
            <Box className="chart-container">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="category" />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} />
                  <Radar name="Tu Empresa" dataKey="percentage" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} />
                  <Radar name="Empresa Promedio" dataKey="average" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.6} />
                  <Legend />
                </RadarChart>
              </ResponsiveContainer>
            </Box>
          </Grid>
        </Grid>
        <Box className="recommendations-container">
          <Typography variant="h6" gutterBottom className="recommendations-title">
            Recomendaciones
          </Typography>
          {recommendations.map((rec, index) => (
            <Typography key={index} variant="body1" gutterBottom className="recommendation-item">
              {rec}
            </Typography>
          ))}
        </Box>
      </Paper>
    </Container>
  );
};

export default Results;