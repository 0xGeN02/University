import React, { useState, useEffect } from 'react';
import { Container, Paper, Typography, Box, Button, SelectChangeEvent } from '@mui/material';
import { generalQuestions, educationSectorQuestions, healthSectorQuestions, manufacturingSectorQuestions, commerceSectorQuestions, servicesSectorQuestions, tourismSectorQuestions, technologySectorQuestions } from '../data/sector_questions';
import Question from './Question';
import MarketSelector from './MarketSelector';
import '../styles/SurveyForm.css';

interface Answer {
  questionId: number;
  answer: string;
  weight: number;
}

interface QuestionType {
  id: number;
  question: string;
  options: { text: string; weight: number }[];
}

const sectorQuestionsMap: { [key: string]: QuestionType[] } = {
  education: educationSectorQuestions,
  health: healthSectorQuestions,
  manufacturing: manufacturingSectorQuestions,
  commerce: commerceSectorQuestions,
  services: servicesSectorQuestions,
  tourism: tourismSectorQuestions,
  technology: technologySectorQuestions,
};

const MarketForm: React.FC = () => {
  const [selectedSector, setSelectedSector] = useState<string>('');
  const [answers, setAnswers] = useState<Answer[]>([]);

  useEffect(() => {
    const generalAnswers: Answer[] = JSON.parse(localStorage.getItem('generalAnswers') || '[]');
    const sectorAnswers: Answer[] = JSON.parse(localStorage.getItem('sectorAnswers') || '[]');
    setAnswers([...generalAnswers, ...sectorAnswers]);
  }, []);

  const handleSectorChange = (event: SelectChangeEvent<string>) => {
    setSelectedSector(event.target.value as string);
  };

  const handleChange = (questionId: number, answer: string, weight: number) => {
    setAnswers((prevAnswers) => {
      const existingAnswer = prevAnswers.find((ans) => ans.questionId === questionId);
      if (existingAnswer) {
        return prevAnswers.map((ans) =>
          ans.questionId === questionId ? { ...ans, answer, weight } : ans
        );
      } else {
        return [...prevAnswers, { questionId, answer, weight }];
      }
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('marketAnswers', JSON.stringify(answers));
    window.location.href = '/results';
  };

  const sectorQuestions = selectedSector ? sectorQuestionsMap[selectedSector] : [];

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Paper elevation={3} className="survey-form-container">
        <Typography variant="h4" gutterBottom className="survey-form-title">
          Encuesta de Mercado
        </Typography>
        <form onSubmit={handleSubmit} className="survey-form">
          {generalQuestions.map((q) => (
            <Question
              key={q.id}
              id={q.id}
              question={q.question}
              options={q.options}
              handleChange={(answer, weight) => handleChange(q.id, answer, weight)}
            />
          ))}
          <MarketSelector selectedSector={selectedSector} handleSectorChange={handleSectorChange} />
          {sectorQuestions.map((q) => (
            <Question
              key={q.id}
              id={q.id}
              question={q.question}
              options={q.options}
              handleChange={(answer, weight) => handleChange(q.id, answer, weight)}
            />
          ))}
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
            <Button
              variant="contained"
              color="primary"
              type="submit"
              sx={{ px: 4, py: 1.5, fontSize: '1rem' }}
              disabled={selectedSector === '' || sectorQuestions.length === 0}
            >
              Enviar
            </Button>
          </Box>
        </form>
      </Paper>
    </Container>
  );
};

export default MarketForm;