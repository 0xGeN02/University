// src/components/ProgressBar.tsx
import React from 'react';
import { Box, LinearProgress, Typography } from '@mui/material';

type ProgressBarProps = {
  completionPercentage: number;
};

const ProgressBar: React.FC<ProgressBarProps> = ({ completionPercentage }) => {
  return (
    <Box className="progress-bar-container">
      <Typography variant="body2" className="progress-bar-text">
        {`Progreso: ${Math.round(completionPercentage)}%`}
      </Typography>
      <LinearProgress
        variant="determinate"
        value={completionPercentage}
        className="linear-progress-bar"
      />
    </Box>
  );
};

export default ProgressBar;
