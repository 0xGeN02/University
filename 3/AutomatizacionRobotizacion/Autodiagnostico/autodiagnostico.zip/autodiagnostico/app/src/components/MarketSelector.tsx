import React from 'react';
import { FormControl, InputLabel, Select, MenuItem, SelectChangeEvent } from '@mui/material';

interface MarketSelectorProps {
  selectedSector: string;
  handleSectorChange: (event: SelectChangeEvent<string>) => void;
}

const MarketSelector: React.FC<MarketSelectorProps> = ({ selectedSector, handleSectorChange }) => {
  return (
    <FormControl fullWidth sx={{ mt: 4 }}>
      <InputLabel id="market-sector-label">Seleccione el sector de su empresa</InputLabel>
      <Select
        labelId="market-sector-label"
        value={selectedSector}
        onChange={handleSectorChange}
        label="Seleccione el sector de su empresa"
      >
        <MenuItem value="education">Educación</MenuItem>
        <MenuItem value="health">Salud</MenuItem>
        <MenuItem value="manufacturing">Manufactura</MenuItem>
        <MenuItem value="commerce">Comercio</MenuItem>
        <MenuItem value="services">Servicios</MenuItem>
        <MenuItem value="tourism">Turismo</MenuItem>
        <MenuItem value="technology">Tecnología</MenuItem>
      </Select>
    </FormControl>
  );
};

export default MarketSelector;