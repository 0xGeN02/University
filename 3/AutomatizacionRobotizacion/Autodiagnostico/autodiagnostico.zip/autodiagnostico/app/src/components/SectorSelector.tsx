import React from 'react';
import { FormControl, InputLabel, Select, MenuItem, SelectChangeEvent } from '@mui/material';

interface SectorSelectorProps {
  selectedSector: string;
  disabled: boolean;
  handleSectorChange: (event: SelectChangeEvent<string>) => void;
}

const SectorSelector: React.FC<SectorSelectorProps> = ({ selectedSector, handleSectorChange, disabled }) => {
  return (
    <FormControl fullWidth sx={{ mt: 4 }} disabled={disabled}>
      <InputLabel id="sector-label">Seleccione el sector de su empresa</InputLabel>
      <Select
        labelId="sector-label"
        value={selectedSector}
        onChange={handleSectorChange}
        label="Seleccione el sector de su empresa"
        disabled={disabled}
      >
        <MenuItem value="primario">Primario</MenuItem>
        <MenuItem value="secundario">Secundario</MenuItem>
        <MenuItem value="terciario">Terciario</MenuItem>
      </Select>
    </FormControl>
  );
};

export default SectorSelector;