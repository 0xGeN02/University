// src/components/MoreInfo.tsx
import React from 'react';
import '../styles/MasInfo.css';

const MasInfo: React.FC = () => {
    return (
        <div className='more-info-container'>
            <header className='info-header'>
                <h1>Beneficios de la Digitalización y Automatización</h1>
                <p>Descubre cómo estas herramientas pueden transformar tu negocio</p>
            </header>
            
            <section className='info-section'>
                <h2>¿Por qué Automatizar y Digitalizar?</h2>
                <p>
                    La automatización y digitalización de procesos permite reducir el tiempo en tareas repetitivas, mejorar la precisión de las operaciones, y aumentar la productividad. 
                    En un mercado en constante cambio, estas herramientas te ayudarán a adaptarte y a mantener una ventaja competitiva.
                </p>
            </section>

            <section className='benefits-section'>
                <div className='benefit-card'>
                    <h3>1. Incremento de la Eficiencia</h3>
                    <p>
                        La automatización permite reducir errores humanos y optimizar el tiempo, dando a tus empleados la oportunidad de concentrarse en tareas estratégicas.
                    </p>
                </div>
                <div className='benefit-card'>
                    <h3>2. Ahorro en Costos</h3>
                    <p>
                        Al automatizar procesos, se reducen los costos asociados a tareas manuales y se minimiza la necesidad de recursos adicionales.
                    </p>
                </div>
                <div className='benefit-card'>
                    <h3>3. Mejora en la Toma de Decisiones</h3>
                    <p>
                        La digitalización permite obtener datos en tiempo real, lo que facilita decisiones informadas y ayuda a predecir tendencias y patrones de negocio.
                    </p>
                </div>
            </section>

            <section className='cta-section'>
                <h2>¿Listo para dar el siguiente paso?</h2>
                <p>
                    Realiza nuestro cuestionario de autodiagnóstico y descubre el potencial de la automatización en tu empresa.
                </p>
                <button onClick={() => window.location.href = '/survey'} className='start-survey-button'>
                    Comenzar cuestionario
                </button>
            </section>
        </div>
    );
}

export default MasInfo;
