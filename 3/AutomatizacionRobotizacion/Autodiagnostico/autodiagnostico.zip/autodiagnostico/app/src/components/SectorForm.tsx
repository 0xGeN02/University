import React, { useState, useEffect } from 'react';
import { Container, Paper, Typography, Box, Button } from '@mui/material';
import { primarioQuestions, secundarioQuestions, terciarioQuestions, QuestionType } from '../data/questions';
import Question from './Question';
import '../styles/SectorForm.css';

interface Answer {
  questionId: number;
  answer: string;
  weight: number;
  category?: string;
}

interface Question {
  id: number;
  question: string;
  options: { text: string; weight: number }[];
  category?: string;
}

const SectorForm: React.FC<{ sector: string }> = ({ sector }) => {
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [isSubmitDisabled, setIsSubmitDisabled] = useState<boolean>(true);
  const questions: QuestionType[] = sector === 'primario' ? primarioQuestions : sector === 'secundario' ? secundarioQuestions : terciarioQuestions;

  useEffect(() => {
    const generalAnswers: Answer[] = JSON.parse(localStorage.getItem('generalAnswers') || '[]');
    setAnswers(generalAnswers);
  }, []);

  useEffect(() => {
    const answeredQuestions = answers.filter(answer => 
      questions.some((q: Question) => q.id === answer.questionId)
    ).length;

    setIsSubmitDisabled(answeredQuestions !== 5);
  }, [answers, questions]);

  const handleChange = (questionId: number, answer: string, weight: number, category?: string) => {
    setAnswers((prevAnswers) => {
      const existingAnswer = prevAnswers.find((ans) => ans.questionId === questionId);
      if (existingAnswer) {
        return prevAnswers.map((ans) =>
          ans.questionId === questionId ? { ...ans, answer, weight, category } : ans
        );
      } else {
        return [...prevAnswers, { questionId, answer, weight, category }];
      }
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('sectorAnswers', JSON.stringify(answers));
    window.location.href = '/survey/market';
  };

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Paper elevation={3} className="survey-form-container">
        <Typography variant="h4" gutterBottom className="survey-form-title">
          Encuesta de Madurez Digital - Sector {sector.charAt(0).toUpperCase() + sector.slice(1)}
        </Typography>
        <form onSubmit={handleSubmit} className="survey-form">
          {questions.map((q) => (
            <Question
              key={q.id}
              id={q.id}
              question={q.question}
              options={q.options}
              handleChange={(answer, weight) => handleChange(q.id, answer, weight, q.category)}
            />
          ))}
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
            <Button
              variant="contained"
              color="primary"
              type="submit"
              sx={{ px: 4, py: 1.5, fontSize: '1rem' }}
              disabled={isSubmitDisabled}
            >
              Enviar
            </Button>
          </Box>
        </form>
      </Paper>
    </Container>
  );
};

export default SectorForm;