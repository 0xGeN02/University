// src/components/Landing.tsx
import React from 'react';
import '../styles/Landing.css';

const Landing: React.FC = () => {
    const handleStart = () => {
        window.location.href = '/survey';
    };

    const handleMoreInfo = () => {
        window.location.href = '/info';
    };

    return (
        <div className="landing-container">
            <div className="overlay" />
            <header className="landing-header">
                <img src="/logo.png" alt="Logo" className="logo" />
                <button className="header-button" onClick={handleMoreInfo}>
                    Más información
                </button>
            </header>
            
            <div className="landing-content">
                <h1 className="landing-title">
                    Automatización y <span className="highlight">Digitalización</span> Empresarial
                </h1>
                <p className="landing-subtitle">
                    Descubre cómo la automatización de procesos puede transformar tu negocio y llevarlo al siguiente nivel.
                </p>

                <div className="cta-container">
                    <button onClick={handleStart} className="start-button">
                        Comenzar cuestionario
                    </button>
                    <button onClick={handleMoreInfo} className="learn-more-button">
                        Más información
                    </button>
                </div>
            </div>
            
            <section className="info-section">
                <div className="info-card">
                    <h3>Optimización de Procesos</h3>
                    <p>Automatiza las tareas repetitivas y mejora la eficiencia operativa de tu negocio.</p>
                </div>
                <div className="info-card">
                    <h3>Reducción de Costos</h3>
                    <p>Minimiza los costos operativos con una estrategia de digitalización eficiente.</p>
                </div>
                <div className="info-card">
                    <h3>Mejora de la Toma de Decisiones</h3>
                    <p>Obtén datos en tiempo real para una toma de decisiones más informada.</p>
                </div>
            </section>
        </div>
    );
};

export default Landing;
