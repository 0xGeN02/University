import React from 'react';
import { FormControl, FormLabel, RadioGroup, FormControlLabel, Radio } from '@mui/material';

interface QuestionProps {
  id: number;
  question: string;
  options: { text: string; weight: number }[];
  handleChange: (answer: string, weight: number) => void;
}

const Question: React.FC<QuestionProps> = ({ id, question, options, handleChange }) => {
  const handleOptionChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedOption = options.find(option => option.text === event.target.value);
    if (selectedOption) {
      handleChange(event.target.value, selectedOption.weight);
    }
  };

  return (
    <div className='question-container'>
      <FormControl component="fieldset">
        <FormLabel component="legend">{question}</FormLabel>
        <RadioGroup name={`question-${id}`} onChange={handleOptionChange}>
          {options.map((option) => (
            <FormControlLabel
              key={option.text}
              value={option.text}
              control={<Radio />}
              label={option.text}
            />
          ))}
        </RadioGroup>
      </FormControl>
    </div>
  );
};

export default Question;