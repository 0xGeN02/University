import React from 'react';
import SurveyForm from './components/SurveyForm';
import SectorForm from './components/SectorForm';
import Landing from './components/Landing';
import Results from './components/Results';
import MasInfo from './components/MasInfo';
import MarketForm from './components/MarketForm';
import { ToastContainer } from 'react-toastify';

const handlePath = (pathname: string) => {

  return (
    <div>
      {pathname === '/' && <Landing />}
      {pathname === '/info' && <MasInfo />}
      {pathname === '/survey' && <SurveyForm />}
      {pathname === '/survey/primario' && <SectorForm sector="primario" />}
      {pathname === '/survey/secundario' && <SectorForm sector="secundario" />}
      {pathname === '/survey/terciario' && <SectorForm sector="terciario" />}
      {pathname === '/survey/market' && <MarketForm />}
      {pathname === '/results' && <Results />}
    </div>
  );
};

const App: React.FC = () => {
  const pathname = window.location.pathname;

  return (
    <>
      {handlePath(pathname)}
      <ToastContainer />
    </>
  );
};

export default App;