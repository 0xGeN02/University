"""
constants/config.py
"""

# Conectividad
ETHERNET_STATIC_IP: str = "169.254.200.200"
IP_ADDRESS: str = "127.0.0.1"
PORT = 9090
HOTSPOT_ADDRESS: str = "10.10.10.10"
HOTSPOT_NAME: str = "ea-40f-1a0"
HOTSPOT_PASSWORD: str = "niryorobot"

# Dimensiones del papel DIN A3
DIN_A3_WIDTH = 0.043
DIN_A3_HEIGHT = -0.2

# Coordenadas iniciales del robot
ROBOT_X = 0.152
ROBOT_Y = 0.19
ROBOT_Z = 0.063
ROBOT_ROLL = -0.027
ROBOT_PITCH = -0.025
ROBOT_YAW = 1.517
INITIAL_COORDENATE = [ROBOT_X, ROBOT_Y, ROBOT_Z, ROBOT_ROLL, ROBOT_PITCH, ROBOT_YAW]
