"""
    main.py
"""
from constants import config
from framework.framework import Framework
from robot.robot import RobotDrawer
from robot.shapes import ShapeDrawer

async def main():
    """
    Punto de entrada del programa.
    """
    # Crear el marco
    paper = Framework(config.DIN_A3_WIDTH, config.DIN_A3_HEIGHT)

    # Conectar al robot
    robot = RobotDrawer(config.HOTSPOT_ADDRESS, config.PORT)

    # Verificar la conexión
    if robot is None:
        print("Conexión fallida.")
        return
    print("Robot conectado con éxito.")

    # Calcular el centro del marco
    paper_center = paper.get_center()
    print(f"Centro del papel: {paper_center}")

    # Mover el robot al punto inicial
    robot.move_to_starting_point()

    # Dibujar un cuadrado
    square_center = [paper_center[0], paper_center[1]]
    corners = ShapeDrawer.calculate_square_corners(square_center, 0.1)
    for point in corners:
        robot.move_to_position(point[0], point[1])

    # Mover al modo de reposo
    robot.arm.go_to_sleep()

if __name__ == "__main__":
    main()
