"""
robot/robot.py
"""

import pyniryo2 as pn2
from constants import config

class RobotDrawer(pn2.NiryoRobot):
    """
    Definición del robot que es capaz de dibujar.
    """
    def __init__(self, hotspot_address: str, port: int):
        super().__init__(hotspot_address, port)
        self.arm.calibrate_auto()
        self.arm.go_to_sleep()
        self.tool.update_tool()

    def move_to_position(self, x: float = None, y: float = None, z: float = None,
                               roll: float = None, pitch: float = None, yaw: float = None):
        """
        Mueve el robot a una posición específica.
        """
        current_pose = self.arm.get_pose()
        new_pose = [
            x if x is not None else current_pose[0],
            y if y is not None else current_pose[1],
            z if z is not None else current_pose[2],
            roll if roll is not None else current_pose[3],
            pitch if pitch is not None else current_pose[4],
            yaw if yaw is not None else current_pose[5]
        ]
        self.arm.move_pose(new_pose)

    def move_to_starting_point(self):
        """
        Mueve el robot a las coordenadas iniciales definidas.
        """
        self.arm.move_pose(config.INITIAL_COORDENATE)
